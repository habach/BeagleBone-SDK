description :
	a program access environment variable and print HOME , UserName, PWD

how to run ?
	1. "make all"
	2. "./t"