description 
	a program copy ls command function with a some argument pass via terminal

how to run ? 
	1. "make all"
	2. ./t -la