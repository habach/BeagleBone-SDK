description:
	3 programs run parallel to check background , foreground process

how to run ?
	1. "make all"
	2. open terminal run :  ./A | ./B | ./C &