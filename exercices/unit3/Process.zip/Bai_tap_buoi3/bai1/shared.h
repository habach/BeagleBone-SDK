#include <stdio.h>

void share_foo(char *);
