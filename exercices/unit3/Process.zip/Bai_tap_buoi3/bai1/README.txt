description:
	build a share library
how to run ?

	1. "make all"
	2. get a file "libshared.so" . that is share lib after build

note :
	in read file "Bai 2/buoi2/bai5/main.c" to using share library