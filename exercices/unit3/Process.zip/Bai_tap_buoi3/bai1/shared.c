#include "shared.h"

void share_foo(char *s)
{
	puts("ok");
	puts(s);
}
