description : get session id of some process on one terminal and 2 terminal

how to run ?
	1. "make all"
	2. test 1: open 1 terminal and run sequense ./A ./B ./C
	   test 2: open 2 terminal and run ./A ./B on first terminal , ./C on other
	