description:
	a process create 2 thread write to a file using mutex to synchronize

how to run ?
	1. make
	2. ./t