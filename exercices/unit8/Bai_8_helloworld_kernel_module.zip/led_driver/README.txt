description:
	driver control led build-in (green) on orangepi zero board . 
	turn on led when user insmod driver to system 
	turn off when rmmod driver

how to run ?
	1. make all
	2 . check led status on board orangepi zeros

note LED GREEN is PA17 pin