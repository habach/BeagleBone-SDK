description:
	a process create n thread write to m file a string
	using semaphore to synchronized ,

how to run ?
	1. make 
	2. ./t 